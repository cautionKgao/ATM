﻿Imports System
Imports System.Numerics


Public Class Form1
    'declare variables
    Dim acc_num As BigInteger = 12345678
    Dim psw As BigInteger = 1234

    'speech
    Dim spi As Object = CreateObject("SAPI.spvoice")

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim userAcc As Integer = TextBox1.Text
        Dim userPsw As Integer = TextBox2.Text
        Dim attempts As Integer = 0
        Dim isBlocked As Boolean = False
        'Given 3 attempts to enter correct details
        If userAcc = acc_num AndAlso userPsw = psw Then
            spi.Speak("Hello there, you have locked in successfully. We're now taking you to the transaction screen")
            'main page
        Else
            attempts += 1
            If attempts < 3 Then
                If userAcc <> acc_num AndAlso userPsw = psw Then
                    spi.Speak("The account number you have entered is invalid, please try again")
                ElseIf userAcc = acc_num AndAlso userPsw <> psw Then
                    spi.Speak("The password you have entered is incorrect, please try again")
                End If
            Else
                spi.Speak("You have entered incorrect details three times, you have been blocked")
            End If
        End If

    End Sub
End Class
